package com.model;

public class Persona {

	public enum genero{
		HOMBRE, MUJER
	}
}
